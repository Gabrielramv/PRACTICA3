#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int matriz[10][12];
	int f,c,i,a,mayor, menor,mayor2;
	int suma1,suma2,suma3,suma4,suma5,suma6,suma7,suma8,suma9,suma0;

	
	
	for(f=0; f<10; f++){
		for(c=0; c<12; c++){
     	matriz[f][c]=rand()%100+1;
        }
	}
		
	 for(f=0; f<10; f++){
        for(c=0; c<12; c++){
            printf("%d ", matriz[f][c]);
            printf("\t");
        }
        printf("\n");	
 	}
	   
	a=1;
	suma1=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];

	a=2;
	suma2=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 
	a=3;
	suma3=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 	
	a=4;
	suma4=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 	
	a=5;
	suma5=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 	
	a=6;
	suma6=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 	
	a=7;
	suma7=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
	
	a=8;
	suma8=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];	
		 
	a=9;
	suma9=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0];
		 	
	a=0;
	suma0=matriz[a][1]+matriz[a][2]+matriz[a][3]+matriz[a][4]+matriz[a][5]
	   	 +matriz[a][6]+matriz[a][7]+matriz[a][8]+matriz[a][9]+matriz[a][10]
		 +matriz[a][11]+matriz[a][0]; 
		 
	printf("\nSonora:%d\n",suma0);
	printf("\nAguascalientes:%d\n",suma1);
	printf("\nOaxaca:%d\n",suma2);
	printf("\nColima:%d\n",suma3);
	printf("\nChihuahua:%d\n",suma4);
	printf("\nSan Luis Potosi:%d\n",suma5);
	printf("\nDurango:%d\n",suma6);
	printf("\nVeracruz:%d\n",suma7);
	printf("\nYucatan:%d\n",suma8);
	printf("\nTabasco:%d\n",suma9);
	
	int sumatoria[10]={suma0,suma1,suma2,suma3,suma4,suma5,suma6,suma7,suma8,suma9};
	
	mayor=sumatoria[0];
	menor=mayor;
	
	for(i=1;i<10;i++){
		if(sumatoria[i]>mayor){
			mayor=sumatoria[i];
		}
		if(sumatoria[i]<menor){
			menor=sumatoria[i];
		}
	}

	
	printf("\n\nEl resultado de mayor registro es:\t%d",mayor);
	printf("\n\nEl resultado de menor registro es:\t%d",menor);
	
	a=1;
	int Aguascalientes[12]={matriz[a][1],matriz[a][2],matriz[a][3],
							matriz[a][4],matriz[a][5],matriz[a][6],
							matriz[a][7],matriz[a][8],matriz[a][9],
							matriz[a][10],matriz[a][11],matriz[a][0]};
												
	mayor2=Aguascalientes[0];
	menor=mayor2;
	
	for(i=1;i<12;i++){
		if(Aguascalientes[i]>mayor2){
			mayor2=Aguascalientes[i];
		}
	}

	printf("\n\nMayor registro de lluvias en aguascalienteses:\t%d",mayor2);						
	
    return 0;
}

	
	
	

