
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>


float Determinante (float **, int);
void Adjunta (float **, float **, int, int);
 

void main()
{
    int n, i, f, c;
    float **matriz;
    char comando;
    
    printf("Introduzca el orden de la matriz\t");
    scanf("%d", &n);
    
    matriz=(float**)calloc(n, sizeof(float*));
    
    if(matriz==NULL)
    printf("ERROR, FALTA MEMORIA PARA LA MATRIZ. Introduzca un orden MUCHO mas peque�o");
    
	else{
    		for(i=0; i<n; i++)
        	matriz[i]=(float*)calloc(n, sizeof(float));   
    
    
    		for(f=0; f<n; f++)
        		for(c=0; c<n; c++){
				printf("\nIntroduce el elemento %d de la fila %d:\t", c+1, f+1);
            	scanf("%f", &matriz[f][c]); 
           	 }

    for(f=0; f<n; f++){
           
            for(c=0; c<n; c++){
            	
                printf("%12.1f ", matriz[f][c]);
        	}
            printf("\n");
        }
     
     printf("\n\t El determinante es:");
     printf("\n\t%.1f", Determinante(matriz, n));
    
    
         
    }
     

}

float Determinante (float **mat, int orden)
{
    float det;
    int h;
    float **auxiliar;

    if(orden<=2){
            if(orden==2)
                det=mat[0][0]*mat[1][1]-(mat[1][0]*mat[0][1]);
                               
            else
                det=mat[0][0];
        }

    else
        {
        auxiliar=(float**)calloc(orden-1, sizeof(float*));
            for(h=0; h<orden-1; h++)
                auxiliar[h]=(float*)calloc(orden-1, sizeof(float));
                det=0;    
                for(h=0; h<orden; h++){               
				Adjunta(mat, auxiliar, orden, h);
                det+=pow(-1, h)*mat[h][0]*Determinante(auxiliar, orden-1);
                }
                free(auxiliar);
        }
        
        
        return(det);
        
}



void Adjunta (float **mat, float **aux, int orden, int pos)
{
    int fila, columna, j, i;
    
    for(j=0, fila=0; fila<orden-1; j++, fila++)
        {
                if(j==pos)
                                fila--;
                else
                        for(i=1, columna=0; columna<orden-1; i++, columna++){
						
                              aux[fila][columna]=mat[j][i];
            }
         }                      


	return 0;
}
