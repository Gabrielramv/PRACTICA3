#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int i, j, lab[5][6]={{1,2,1,1,0,0},{1,0,1,1,0,1},{1,0,1,1,0,1},{1,0,0,0,0,1},{1,1,0,1,1,1}};
  char posicion;
  for (i=0;i<5;i++){
   for (j=0;j<6;j++){
    printf ("%d\t",lab[i][j]);
   }
   printf ("\n");
  }
  do{
  	char posicion;
  	printf ("\nA)Arriba\nB)Abajo\nI)Izquierda\nD)Derecha\nIntroduce la letra del menu que indique la direccion a la que deseas avanzar:\n");
    scanf (" %c",&posicion);    
    switch (posicion){     
     case 'A':
          
      for (i=0;i<5;i++){
       for (j=0;j<6;j++){
        if (lab[i][j]==2 && lab[(i-1)][j]!=1){
         lab [i][j]=0;
         lab [i-1][j]=2;
         goto eti;
        }
       }
      }
     break;
          
	 case 'B':
      for (i=0;i<5;i++){
       for (j=0;j<6;j++){
        if (lab[i][j]==2 && lab[(i+1)][j]!=1){
         lab [i][j]=0;
         lab [(i+1)][j]=2;
         goto eti;
        }
       }
      }    
     break;
          
	 case 'I':
      for (i=0;i<5;i++){
       for (j=0;j<6;j++){
        if (lab[i][j]==2 && lab[i][(j-1)]!=1){
         lab [i][j]=0;
         lab [i][j-1]=2;
         goto eti;
        }
       }
      }    
     break;
     
	 case 'D':
      for (i=0;i<5;i++){
       for (j=0;j<6;j++){
        if (lab[i][j]==2 && lab[i][(j+1)]!=1){
         lab [i][j]=0;
         lab [i][(j+1)]=2;
         goto eti;
        }
       }
      }
     break;
     
     default: printf("\nLetra ingresada invalida\n");
     break;
    }
    eti:
    printf ("\n");
	 for (i=0;i<5;i++){
      for (j=0;j<6;j++){
       printf ("%d\t",lab[i][j]);
      }
      printf ("\n");
	 }
  }
  while (lab[0][5]!=2); 
  printf ("\nHas llegado, FELICIDADES!\n");
  system("PAUSE");	
  return 0;
}
