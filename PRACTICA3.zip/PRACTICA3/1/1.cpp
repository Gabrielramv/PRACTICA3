#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
    int i,j,d,f;
    int vector[100];
    int histograma[10];

    for(i=0;i<100;i++){
        
        vector[i]=rand()%10+1;
        printf("%d",vector[i]);
    
    printf("\t");
	}
    for(i=0;i<10;i++){
    	histograma[i]=0;
	}
	for(i=0;i<100;i++){
		d=vector[i]-1;
		histograma[d]=histograma[d]+1;
	}
	for(i=0;i<10;i++){
		
		printf("\n\n%d:",i+1);
		f=histograma[i];
		
		for(j=0;j<f;j++){
			printf("*");
		}		
	}

    return 0;
}

